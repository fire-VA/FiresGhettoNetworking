* v1.0.2 update for not playing well with wackies db
* v1.1.0 compatibility updates 
